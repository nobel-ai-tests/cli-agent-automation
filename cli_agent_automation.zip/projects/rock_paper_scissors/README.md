# Rock, Paper, Scissors Game

A simple web-based Rock, Paper, Scissors game implemented using HTML, CSS, and JavaScript.

## Plan

1.  **HTML Structure (`index.html`):**
    *   Create a container for the game.
    *   Add buttons for the player to select Rock, Paper, or Scissors.
    *   Add display areas for the player's choice, the computer's choice, and the round result.
    *   Add a scoreboard to track player and computer wins.
    *   Add a reset button to clear scores and choices.

2.  **Styling (`style.css`):**
    *   Center the game UI on the page.
    *   Style buttons for a clear, interactive feel.
    *   Implement visual feedback for wins, losses, and draws (e.g., color changes).
    *   Ensure a responsive and clean layout.

3.  **Game Logic (`script.js`):**
    *   Add event listeners to the player selection buttons.
    *   Implement a function to generate a random choice for the computer.
    *   Create a function to determine the winner based on the classic rules:
        *   Rock beats Scissors.
        *   Scissors beats Paper.
        *   Paper beats Rock.
    *   Update the score tracking variables.
    *   Update the DOM to display choices, results, and current scores.
    *   Implement reset functionality to clear all game states.