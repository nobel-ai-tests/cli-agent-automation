# Tic-Tac-Toe Project Plan

This project implements a simple, two-player Tic-Tac-Toe game using web technologies.

## Plan

1.  **Layout**: Create a centered 3x3 grid using HTML and CSS.
2.  **State Management**: Use JavaScript to track the board state (9 cells), the current player (X or O), and the game status (active/inactive).
3.  **Interaction**: Implement click handlers for cells to mark them with the current player's symbol.
4.  **Win/Draw Logic**:
    *   Check for 3-in-a-row horizontally, vertically, or diagonally after each move.
    *   Check for a draw if all cells are filled without a winner.
5.  **Game Control**: Add a reset button to clear the board and start a new game.
6.  **Visuals**: Use CSS for clear borders, grid alignment, and player symbol styling.